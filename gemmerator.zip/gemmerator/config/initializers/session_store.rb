# Be sure to restart your server when you modify this file.

Gemmerator::Application.config.session_store :cookie_store, key: '_gemmerator_session'
